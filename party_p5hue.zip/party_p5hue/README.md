p5hue
=====

simple control program for Philips' HUE lights with Processing

//Noriyuki Fujimura, nori_fujimura@me.com www.norifujimura.com
//Jan 20th 2014
//HueHub and HueLight class is from 
//https://github.com/jvandewiel/hue
